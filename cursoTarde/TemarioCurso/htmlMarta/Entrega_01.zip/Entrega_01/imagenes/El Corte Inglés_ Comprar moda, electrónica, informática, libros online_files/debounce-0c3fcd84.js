const d=(t,i,{leading:r}={})=>{let e;return(...o)=>{!e&&r&&t(...o),clearTimeout(e),e=setTimeout(()=>t(...o),i)}};export{d};
//# sourceMappingURL=debounce-0c3fcd84.js.map
