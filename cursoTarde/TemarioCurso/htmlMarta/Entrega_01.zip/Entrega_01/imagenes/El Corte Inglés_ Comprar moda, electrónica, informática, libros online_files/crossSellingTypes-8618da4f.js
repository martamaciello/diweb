const e=Object.freeze({WPC:"wpc",VUE:"vue",RR:"rich_relevance",RM:"retail_media",SIA:"sia"});export{e as C};
//# sourceMappingURL=crossSellingTypes-8618da4f.js.map
